<h1> <b>ESS</b>2<b>CALENDAR</b></h1>
<?php /**PATH C:\Users\jaspe\PhpstormProjects\Ess2Calendar\resources\views/components/application-logo.blade.php ENDPATH**/ ?>