<?php echo e($slot); ?>

<?php /**PATH C:\Users\jaspe\PhpstormProjects\Ess2Calendar\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>